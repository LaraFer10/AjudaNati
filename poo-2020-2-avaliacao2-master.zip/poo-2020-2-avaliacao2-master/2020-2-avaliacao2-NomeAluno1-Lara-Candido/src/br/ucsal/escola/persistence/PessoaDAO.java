package br.ucsal.escola.persistence;

import java.util.ArrayList;

import br.ucsal.escola.domain.Aluno;
import br.ucsal.escola.domain.Pessoa;

public class PessoaDAO {

	public static ArrayList<Pessoa> pessoas = new ArrayList<Pessoa>();
	
	public static void inserirAluno(Aluno aluno) {
		pessoas.add(aluno);
	}
	
	public static ArrayList<String> obterPessoasOrdemNome(){
		ArrayList<String> nomesPessoas = new ArrayList<String>();
		for (Pessoa item : pessoas) {
			nomesPessoas.add(item.getNome());
		}
		
		return nomesPessoas;
	}
}
