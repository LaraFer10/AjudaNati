package br.ucsal.escola.domain;

public class Professor extends Pessoa {
	private Titulacao titulo;

	public Professor(String nome, String nacionalidade, Titulacao titulo, String telefone) {
		super(nome, nacionalidade);
		this.setTelefone(telefone);
		this.setTitulo(titulo);
	}

	public Professor(String nome, String nacionalidade, Titulacao titulo) {
		super(nome, nacionalidade);
		this.setTitulo(titulo);
	}

	public Titulacao getTitulo() {
		return titulo;
	}

	public void setTitulo(Titulacao titulo) {
		this.titulo = titulo;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + "Titulo: " + titulo.name() + "\n";
	}
}
