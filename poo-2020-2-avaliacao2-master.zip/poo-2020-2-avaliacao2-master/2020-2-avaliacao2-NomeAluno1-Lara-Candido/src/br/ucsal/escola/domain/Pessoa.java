package br.ucsal.escola.domain;

public abstract class Pessoa {
	private String nome, nacionalidade, telefone;

	public Pessoa(String nome, String nacionalidade) {
		this.setNacionalidade(nacionalidade);
		this.setNome(nome);
	}
	
	public Pessoa() {
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Nome: " + nome + 
				"\nNacionalidade: " + nacionalidade + 
				"\nTelefone: " + telefone + "\n";
	}
}
