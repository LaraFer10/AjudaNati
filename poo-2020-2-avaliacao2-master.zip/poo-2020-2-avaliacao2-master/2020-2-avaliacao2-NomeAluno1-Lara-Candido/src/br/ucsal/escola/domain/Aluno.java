package br.ucsal.escola.domain;

import br.ucsal.escola.exceptions.ValorNaoInformadoException;

public class Aluno extends Pessoa {
	private String escolaOrigem;
	private int anoNascimento;

	public Aluno(String nome, String nacionalidade, String telefone, String escolaOrigem, int anoNascimento) throws ValorNaoInformadoException {
		super(nome, nacionalidade);
		this.validarTelefone(telefone);
		this.setTelefone(telefone);
		this.setEscolaOrigem(escolaOrigem);
		this.setAnoNascimento(anoNascimento);

	}
	public Aluno() {

	}

	public int getAnoNascimento() {
		return anoNascimento;
	}

	public void setAnoNascimento(int anoNascimento) {
		this.anoNascimento = anoNascimento;
	}

	public String getEscolaOrigem() {
		return escolaOrigem;
	}

	public void setEscolaOrigem(String escolaOrigem) {
		this.escolaOrigem = escolaOrigem;
	}

	private void validarTelefone(String telefone) throws ValorNaoInformadoException {
		if(telefone.isEmpty()) 
			throw new ValorNaoInformadoException("O campo de telefone � obrigatorio");
	}

	@Override
	public String toString() {
		return super.toString() + "Escola de Origem: " + escolaOrigem  + "\nAno de Nascimento: " + anoNascimento + "\n";
	}
}
