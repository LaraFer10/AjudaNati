package br.ucsal.escola.domain;

public enum Titulacao {
	ESPECIALISTA, MESTRE, DOUTOR;
}
