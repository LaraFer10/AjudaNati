package br.ucsal.escola.business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import br.ucsal.escola.domain.Aluno;
import br.ucsal.escola.exceptions.ValorNaoInformadoException;
import br.ucsal.escola.persistence.PessoaDAO;

public class PessoaBO {

	public static void cadastrarAluno(String nome, String nacionalidade, String telefone, String escolaOrigem, int anoNascimento) throws ValorNaoInformadoException {
		Aluno aluno;

		aluno = new Aluno(nome, nacionalidade, telefone, escolaOrigem, anoNascimento);
		PessoaDAO.inserirAluno(aluno);
	}

	public static ArrayList<String> obterPessoasOrdemNome(){
		ArrayList<String> pessoasNome = PessoaDAO.obterPessoasOrdemNome();
		pessoasNome.sort(Comparator.naturalOrder());
		Collections.sort(pessoasNome);
		return pessoasNome;
	}

}
