package br.ucsal.escola.tui;

import java.util.Scanner;

import br.ucsal.escola.business.PessoaBO;
import br.ucsal.escola.exceptions.ValorNaoInformadoException;

public class PessoaTUI {
	/**
	 * Um m�todo para cadastrar aluno fazer a adequada chamada ao m�todo de neg�cio
	 * e tratar adequadamente as exce��es que podem vir a ocorrer
	 **/
	private static Scanner s = new Scanner(System.in);

	public static void main(String[] args) {
		int n = 0;
		while (n != 2) {
			System.out.println("Bem-vindo ao meu programa");
			System.out.println("1) Cadastre um aluno");
			System.out.println("2) Sair");
			n = s.nextInt();
			s.nextLine();
			if (n == 1)
				cadastrarAluno();
		}
	}

	private static void cadastrarAluno() {
		String nome, telefone, escOrigem, nacion;
		int anoNasc;
		try {
			System.out.print("Informe o nome: ");
			nome = s.nextLine();
			System.out.print("Informe o telefone: ");
			telefone = s.next();
			System.out.print("Informe o ano de nascimento: ");
			anoNasc = s.nextInt();
			s.nextLine();
			System.out.print("Informe a escola de origem: ");
			escOrigem = s.nextLine();
			System.out.print("Informe a nacionalidade: ");
			nacion = s.nextLine();
			
			PessoaBO.cadastrarAluno(nome, nacion, telefone, escOrigem, anoNasc);
			
			System.out.println("Aluno inserido com sucesso.");
		} catch (ValorNaoInformadoException e) {
			System.out.println("Telefone n�o foi inserida.");
			System.out.println("Aluno n�o inserido.");
		}
	}
}
