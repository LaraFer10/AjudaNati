package br.ucsal.escola.exceptions;

public class ValorNaoInformadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private String msg;

	public ValorNaoInformadoException(String msg) {
		super(msg);
		this.msg = msg;
	}

	public String getMessage() {
		return msg;
	}
}
